#!/bin/bash

employee="saipavan"
echo "Dear ${employee}"
echo "The board and I would like to thank you fir the excellent work that you have "
echo "Keep up the good work, ${employee}"

echo "Best wishes,"
echo "saipavan, CEO"
